import java.util.Scanner;

/**
 * Created by ryan hunter on 1/20/17.
 */

// if 40 cookies = 10 servings

// 300 cal. =  10 serving

// 30 cal. = 1 serving

//(7/1) * 30


public class Cookies {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        //State variables
        int servings;
        double totalCalories;


        //input number of cookies ate
        System.out.println("Enter the number of cookies eaten: ");
        // read user input

        int numberOfCookies = keyboard.nextInt();

        //calculate number of calories consumed
        servings = 40 / 10;
        int cookieCalories = 300 / servings;
        totalCalories = numberOfCookies * cookieCalories;


        // print number of calories consumed
        System.out.printf("You consumed %,.2f calories.", totalCalories);
    }
}
