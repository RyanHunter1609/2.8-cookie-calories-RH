/**
 * Created by ryanhunter on 1/20/17.
 */
public class NumericTypes {
    public static void main(String[] args) {

    }
}
